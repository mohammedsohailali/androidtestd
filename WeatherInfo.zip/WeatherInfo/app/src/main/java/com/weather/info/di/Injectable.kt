package com.weather.info.di

/**
 * Marks an activity / fragment injectable.
 */
interface Injectable
